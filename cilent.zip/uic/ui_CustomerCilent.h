/********************************************************************************
** Form generated from reading UI file 'CustomerCilent.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CUSTOMERCILENT_H
#define UI_CUSTOMERCILENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CustomerCilentClass
{
public:
    QWidget *centralWidget;
    QLabel *label_roomid;
    QLabel *label_initial_temp;
    QTextEdit *initial_temp_text;
    QPushButton *turnon_button;
    QTextEdit *show_fee;
    QTextEdit *show_current_temp;
    QLabel *label_fee;
    QLabel *label_current_temp;
    QTextEdit *input_target_temp;
    QLabel *label_change_target_temp;
    QComboBox *input_fan;
    QLabel *label_change_target_fan;
    QPushButton *change_temp_button;
    QPushButton *change_fan_button;
    QPushButton *turnoff_button;
    QTextEdit *roomid_text;
    QTextEdit *show_target_temp;
    QTextEdit *show_target_fan;
    QLabel *label_target_temp;
    QLabel *label_fan;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *CustomerCilentClass)
    {
        if (CustomerCilentClass->objectName().isEmpty())
            CustomerCilentClass->setObjectName(QStringLiteral("CustomerCilentClass"));
        CustomerCilentClass->resize(575, 400);
        centralWidget = new QWidget(CustomerCilentClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        label_roomid = new QLabel(centralWidget);
        label_roomid->setObjectName(QStringLiteral("label_roomid"));
        label_roomid->setGeometry(QRect(50, 0, 51, 16));
        label_initial_temp = new QLabel(centralWidget);
        label_initial_temp->setObjectName(QStringLiteral("label_initial_temp"));
        label_initial_temp->setGeometry(QRect(240, 0, 121, 16));
        initial_temp_text = new QTextEdit(centralWidget);
        initial_temp_text->setObjectName(QStringLiteral("initial_temp_text"));
        initial_temp_text->setGeometry(QRect(230, 20, 121, 31));
        turnon_button = new QPushButton(centralWidget);
        turnon_button->setObjectName(QStringLiteral("turnon_button"));
        turnon_button->setGeometry(QRect(470, 30, 71, 31));
        show_fee = new QTextEdit(centralWidget);
        show_fee->setObjectName(QStringLiteral("show_fee"));
        show_fee->setGeometry(QRect(20, 80, 111, 31));
        show_current_temp = new QTextEdit(centralWidget);
        show_current_temp->setObjectName(QStringLiteral("show_current_temp"));
        show_current_temp->setGeometry(QRect(230, 80, 121, 31));
        label_fee = new QLabel(centralWidget);
        label_fee->setObjectName(QStringLiteral("label_fee"));
        label_fee->setGeometry(QRect(60, 60, 41, 21));
        label_current_temp = new QLabel(centralWidget);
        label_current_temp->setObjectName(QStringLiteral("label_current_temp"));
        label_current_temp->setGeometry(QRect(230, 60, 111, 20));
        input_target_temp = new QTextEdit(centralWidget);
        input_target_temp->setObjectName(QStringLiteral("input_target_temp"));
        input_target_temp->setGeometry(QRect(20, 210, 111, 31));
        label_change_target_temp = new QLabel(centralWidget);
        label_change_target_temp->setObjectName(QStringLiteral("label_change_target_temp"));
        label_change_target_temp->setGeometry(QRect(10, 190, 121, 20));
        input_fan = new QComboBox(centralWidget);
        input_fan->addItem(QString());
        input_fan->addItem(QString());
        input_fan->addItem(QString());
        input_fan->setObjectName(QStringLiteral("input_fan"));
        input_fan->setGeometry(QRect(10, 280, 111, 22));
        label_change_target_fan = new QLabel(centralWidget);
        label_change_target_fan->setObjectName(QStringLiteral("label_change_target_fan"));
        label_change_target_fan->setGeometry(QRect(10, 250, 201, 31));
        change_temp_button = new QPushButton(centralWidget);
        change_temp_button->setObjectName(QStringLiteral("change_temp_button"));
        change_temp_button->setGeometry(QRect(210, 210, 171, 31));
        change_fan_button = new QPushButton(centralWidget);
        change_fan_button->setObjectName(QStringLiteral("change_fan_button"));
        change_fan_button->setGeometry(QRect(210, 270, 171, 31));
        turnoff_button = new QPushButton(centralWidget);
        turnoff_button->setObjectName(QStringLiteral("turnoff_button"));
        turnoff_button->setGeometry(QRect(470, 100, 81, 211));
        roomid_text = new QTextEdit(centralWidget);
        roomid_text->setObjectName(QStringLiteral("roomid_text"));
        roomid_text->setGeometry(QRect(20, 20, 111, 31));
        show_target_temp = new QTextEdit(centralWidget);
        show_target_temp->setObjectName(QStringLiteral("show_target_temp"));
        show_target_temp->setGeometry(QRect(20, 140, 111, 31));
        show_target_fan = new QTextEdit(centralWidget);
        show_target_fan->setObjectName(QStringLiteral("show_target_fan"));
        show_target_fan->setGeometry(QRect(230, 140, 121, 31));
        label_target_temp = new QLabel(centralWidget);
        label_target_temp->setObjectName(QStringLiteral("label_target_temp"));
        label_target_temp->setGeometry(QRect(20, 120, 101, 16));
        label_fan = new QLabel(centralWidget);
        label_fan->setObjectName(QStringLiteral("label_fan"));
        label_fan->setGeometry(QRect(230, 120, 91, 20));
        CustomerCilentClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(CustomerCilentClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 575, 18));
        CustomerCilentClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(CustomerCilentClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        CustomerCilentClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(CustomerCilentClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        CustomerCilentClass->setStatusBar(statusBar);

        retranslateUi(CustomerCilentClass);

        QMetaObject::connectSlotsByName(CustomerCilentClass);
    } // setupUi

    void retranslateUi(QMainWindow *CustomerCilentClass)
    {
        CustomerCilentClass->setWindowTitle(QApplication::translate("CustomerCilentClass", "CustomerCilent", nullptr));
        label_roomid->setText(QApplication::translate("CustomerCilentClass", "RoomID", nullptr));
        label_initial_temp->setText(QApplication::translate("CustomerCilentClass", "Initial Temp", nullptr));
        turnon_button->setText(QApplication::translate("CustomerCilentClass", "Turn on", nullptr));
        label_fee->setText(QApplication::translate("CustomerCilentClass", "Fee", nullptr));
        label_current_temp->setText(QApplication::translate("CustomerCilentClass", "Current Temp", nullptr));
        label_change_target_temp->setText(QApplication::translate("CustomerCilentClass", "Change Target Temp", nullptr));
        input_fan->setItemText(0, QApplication::translate("CustomerCilentClass", "high", nullptr));
        input_fan->setItemText(1, QApplication::translate("CustomerCilentClass", "mid", nullptr));
        input_fan->setItemText(2, QApplication::translate("CustomerCilentClass", "low", nullptr));

        label_change_target_fan->setText(QApplication::translate("CustomerCilentClass", "Change Target Fan Speed", nullptr));
        change_temp_button->setText(QApplication::translate("CustomerCilentClass", "Change Temp", nullptr));
        change_fan_button->setText(QApplication::translate("CustomerCilentClass", "Change Fan Speed", nullptr));
        turnoff_button->setText(QApplication::translate("CustomerCilentClass", "Turn off", nullptr));
        label_target_temp->setText(QApplication::translate("CustomerCilentClass", "Target Temp", nullptr));
        label_fan->setText(QApplication::translate("CustomerCilentClass", "Fan Speed", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CustomerCilentClass: public Ui_CustomerCilentClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CUSTOMERCILENT_H
