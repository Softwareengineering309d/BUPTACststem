/****************************************************************************
** Meta object code from reading C++ file 'ClientTcpSocket.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.10.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../ClientTcpSocket.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ClientTcpSocket.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.10.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ClientTcpSocket_t {
    QByteArrayData data[16];
    char stringdata0[264];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ClientTcpSocket_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ClientTcpSocket_t qt_meta_stringdata_ClientTcpSocket = {
    {
QT_MOC_LITERAL(0, 0, 15), // "ClientTcpSocket"
QT_MOC_LITERAL(1, 16, 22), // "turnOnAirConditionerOK"
QT_MOC_LITERAL(2, 39, 0), // ""
QT_MOC_LITERAL(3, 40, 25), // "turnOnAirConditionerError"
QT_MOC_LITERAL(4, 66, 12), // "changeTempOK"
QT_MOC_LITERAL(5, 79, 15), // "changeTempError"
QT_MOC_LITERAL(6, 95, 16), // "changeFanSpeedOK"
QT_MOC_LITERAL(7, 112, 19), // "changeFanSpeedError"
QT_MOC_LITERAL(8, 132, 21), // "closeAirConditionerOK"
QT_MOC_LITERAL(9, 154, 24), // "closeAirConditionerError"
QT_MOC_LITERAL(10, 179, 9), // "serviceOn"
QT_MOC_LITERAL(11, 189, 19), // "reachTargetTempStop"
QT_MOC_LITERAL(12, 209, 13), // "preemptedStop"
QT_MOC_LITERAL(13, 223, 9), // "heartBeat"
QT_MOC_LITERAL(14, 233, 11), // "receiveData"
QT_MOC_LITERAL(15, 245, 18) // "serverDisconnected"

    },
    "ClientTcpSocket\0turnOnAirConditionerOK\0"
    "\0turnOnAirConditionerError\0changeTempOK\0"
    "changeTempError\0changeFanSpeedOK\0"
    "changeFanSpeedError\0closeAirConditionerOK\0"
    "closeAirConditionerError\0serviceOn\0"
    "reachTargetTempStop\0preemptedStop\0"
    "heartBeat\0receiveData\0serverDisconnected"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ClientTcpSocket[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      12,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    3,   84,    2, 0x06 /* Public */,
       3,    0,   91,    2, 0x06 /* Public */,
       4,    0,   92,    2, 0x06 /* Public */,
       5,    0,   93,    2, 0x06 /* Public */,
       6,    0,   94,    2, 0x06 /* Public */,
       7,    0,   95,    2, 0x06 /* Public */,
       8,    0,   96,    2, 0x06 /* Public */,
       9,    0,   97,    2, 0x06 /* Public */,
      10,    1,   98,    2, 0x06 /* Public */,
      11,    0,  101,    2, 0x06 /* Public */,
      12,    2,  102,    2, 0x06 /* Public */,
      13,    2,  107,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      14,    0,  112,    2, 0x08 /* Private */,
      15,    0,  113,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Float, QMetaType::Int, QMetaType::Bool,    2,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Float, QMetaType::Float,    2,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void ClientTcpSocket::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ClientTcpSocket *_t = static_cast<ClientTcpSocket *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->turnOnAirConditionerOK((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 1: _t->turnOnAirConditionerError(); break;
        case 2: _t->changeTempOK(); break;
        case 3: _t->changeTempError(); break;
        case 4: _t->changeFanSpeedOK(); break;
        case 5: _t->changeFanSpeedError(); break;
        case 6: _t->closeAirConditionerOK(); break;
        case 7: _t->closeAirConditionerError(); break;
        case 8: _t->serviceOn((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->reachTargetTempStop(); break;
        case 10: _t->preemptedStop((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 11: _t->heartBeat((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2]))); break;
        case 12: _t->receiveData(); break;
        case 13: _t->serverDisconnected(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (ClientTcpSocket::*_t)(float , int , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::turnOnAirConditionerOK)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (ClientTcpSocket::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::turnOnAirConditionerError)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (ClientTcpSocket::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::changeTempOK)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (ClientTcpSocket::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::changeTempError)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (ClientTcpSocket::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::changeFanSpeedOK)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (ClientTcpSocket::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::changeFanSpeedError)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (ClientTcpSocket::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::closeAirConditionerOK)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (ClientTcpSocket::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::closeAirConditionerError)) {
                *result = 7;
                return;
            }
        }
        {
            typedef void (ClientTcpSocket::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::serviceOn)) {
                *result = 8;
                return;
            }
        }
        {
            typedef void (ClientTcpSocket::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::reachTargetTempStop)) {
                *result = 9;
                return;
            }
        }
        {
            typedef void (ClientTcpSocket::*_t)(int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::preemptedStop)) {
                *result = 10;
                return;
            }
        }
        {
            typedef void (ClientTcpSocket::*_t)(float , float );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClientTcpSocket::heartBeat)) {
                *result = 11;
                return;
            }
        }
    }
}

const QMetaObject ClientTcpSocket::staticMetaObject = {
    { &QTcpSocket::staticMetaObject, qt_meta_stringdata_ClientTcpSocket.data,
      qt_meta_data_ClientTcpSocket,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *ClientTcpSocket::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ClientTcpSocket::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ClientTcpSocket.stringdata0))
        return static_cast<void*>(this);
    return QTcpSocket::qt_metacast(_clname);
}

int ClientTcpSocket::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTcpSocket::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 14;
    }
    return _id;
}

// SIGNAL 0
void ClientTcpSocket::turnOnAirConditionerOK(float _t1, int _t2, bool _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ClientTcpSocket::turnOnAirConditionerError()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void ClientTcpSocket::changeTempOK()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void ClientTcpSocket::changeTempError()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void ClientTcpSocket::changeFanSpeedOK()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void ClientTcpSocket::changeFanSpeedError()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void ClientTcpSocket::closeAirConditionerOK()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void ClientTcpSocket::closeAirConditionerError()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void ClientTcpSocket::serviceOn(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void ClientTcpSocket::reachTargetTempStop()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void ClientTcpSocket::preemptedStop(int _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void ClientTcpSocket::heartBeat(float _t1, float _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
