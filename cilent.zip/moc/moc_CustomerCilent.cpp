/****************************************************************************
** Meta object code from reading C++ file 'CustomerCilent.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.10.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../CustomerCilent.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CustomerCilent.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.10.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CustomerCilent_t {
    QByteArrayData data[8];
    char stringdata0[86];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CustomerCilent_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CustomerCilent_t qt_meta_stringdata_CustomerCilent = {
    {
QT_MOC_LITERAL(0, 0, 14), // "CustomerCilent"
QT_MOC_LITERAL(1, 15, 6), // "turnon"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 11), // "change_temp"
QT_MOC_LITERAL(4, 35, 10), // "change_fan"
QT_MOC_LITERAL(5, 46, 7), // "turnoff"
QT_MOC_LITERAL(6, 54, 14), // "socketReadData"
QT_MOC_LITERAL(7, 69, 16) // "socketDisconnect"

    },
    "CustomerCilent\0turnon\0\0change_temp\0"
    "change_fan\0turnoff\0socketReadData\0"
    "socketDisconnect"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CustomerCilent[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   44,    2, 0x06 /* Public */,
       3,    0,   45,    2, 0x06 /* Public */,
       4,    0,   46,    2, 0x06 /* Public */,
       5,    0,   47,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    0,   48,    2, 0x08 /* Private */,
       7,    0,   49,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void CustomerCilent::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        CustomerCilent *_t = static_cast<CustomerCilent *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->turnon(); break;
        case 1: _t->change_temp(); break;
        case 2: _t->change_fan(); break;
        case 3: _t->turnoff(); break;
        case 4: _t->socketReadData(); break;
        case 5: _t->socketDisconnect(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (CustomerCilent::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CustomerCilent::turnon)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (CustomerCilent::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CustomerCilent::change_temp)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (CustomerCilent::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CustomerCilent::change_fan)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (CustomerCilent::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CustomerCilent::turnoff)) {
                *result = 3;
                return;
            }
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject CustomerCilent::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_CustomerCilent.data,
      qt_meta_data_CustomerCilent,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *CustomerCilent::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CustomerCilent::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CustomerCilent.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int CustomerCilent::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void CustomerCilent::turnon()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void CustomerCilent::change_temp()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void CustomerCilent::change_fan()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void CustomerCilent::turnoff()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
